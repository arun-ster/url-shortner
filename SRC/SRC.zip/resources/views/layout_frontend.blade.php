<!DOCTYPE html>
<html lang="en">
	<head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta name="description" content="">
            <meta name="author" content="">
            <title>URL Shortner</title>
            <!-- Bootstrap core CSS -->
            <link href="./css/bootstrap.min.css" rel="stylesheet">
            <style>
                body { padding-top: 50px; }
                .starter-template { padding: 40px 15px; text-align: center; }
                .hide {display: none !important}
            </style>
	</head>
	<body>
            <nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="#">URL Shortner</a>
                    </div>                    
                   
                </div>
            </nav>
            @yield('container')
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
        <script src="./js/bootstrap.min.js"></script>
        <script src="./js/jquery.form.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#surl_form').ajaxForm({dataType:  'json',success:create_url});
            });
            function create_url(data){
                $('#response').html('').hide();
                if(data.resp=='success'){                    
                    $('#response').html(data.message).show();
                }
            }
        </script>
    </body>
</html>