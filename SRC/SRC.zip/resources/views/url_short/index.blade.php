@extends('layout_frontend')
@section('container')
    <div class="container">
        <div class="starter-template" style="text-align:left; width:500px;margin:0 auto;" >
            <div id='response'></div>           
            <div class="well">
                <form id='surl_form' name="shorten_url_form" method="post" action="{{ url() }}/create_url">
                    <div class="form-group">
                        <input type="hidden" id="token" name="_token" value="{{ csrf_token() }}" />
                        <label for="exampleInputEmail1">URL </label>
                        <input type="url" class="form-control" required="" name="url" id="url" placeholder="Enter URL">
                    </div>
                    <button type="submit" class="btn btn-success">Shorten</button>
                </form>
            </div>
        </div>
    </div>
@stop