<?php namespace App\Http\Controllers;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UrlController extends Controller {	
	public function __construct()
	{
            //constructor 
	}	
	public function make(Request $request)
	{
            //Function for adding urls
            $result =array();
            $url = trim($request->url,'/');            
            if(trim($request->url==='')){
                $result = array("resp"=>"error","message"=>"<div class='alert alert-error'>Please enter url</div>");
            }
            elseif(filter_var($url, FILTER_VALIDATE_URL) === false){
                $result = array("resp"=>"error","message"=>"<div class='alert alert-error'>Please enter a valid url</div>");
            }
            else{
                
                $unique_id = $this->unique_id(8); //get unique code
                $cur_result = DB::table('url_shortner')->where('url', $url)->first(); //check for duplicate and return existing if exists
                if(count($cur_result)>0){                   
                    $result = array("resp"=>"success","message"=>"<div class='alert alert-success'>Your url has been shortened. Try here <a target='_blank' href='".url()."/go/".$cur_result->short_code."'>".url()."/go/".$cur_result->short_code."</a></div>");
                }
                else{
                    $qv = DB::table('url_shortner')->insert(                        
                          array(
                            'url'   => $url,
                            'short_code' => $unique_id
                            )
                    );                 
                    $result = array("resp"=>"success","message"=>"<div class='alert alert-success'>Your url has been shortened. Try here <a target='_blank' href='".url()."/go/".$unique_id."'>".url()."/go/".$unique_id."</a></div>");
                }
            }
                echo json_encode($result);
           
	}
        public function get($slug=''){
            //Function for redirecting with shortcode
            if(!empty($slug)){
                $url = DB::table('url_shortner')->where('short_code', $slug)->pluck('url');
                return empty($url) ?  redirect(url()) : redirect($url."");                    
            }
            else{
                return redirect(url());
            }
        }
        protected function unique_id($l = 8){
            // Function to create a unique code
            $better_token = md5(uniqid(rand(), true));
            $rem = strlen($better_token)-$l;
            $unique_code = substr($better_token, 0, -$rem);            
            return $unique_code;
        }
}
