<?php namespace App\Http\Controllers;

class HomeController extends Controller {	
	public function __construct()
	{
		//constructor
	}
	
	public function index()
	{       //Function to display add url UI
		return view('url_short.index');
	}

}
